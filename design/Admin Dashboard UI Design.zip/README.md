
  # Admin Dashboard UI Design

  This is a code bundle for Admin Dashboard UI Design. The original project is available at https://www.figma.com/design/iAaPkvmSFhvTutQ73Ud74B/Admin-Dashboard-UI-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  